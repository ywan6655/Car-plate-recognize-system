from flask import Flask, render_template, request
import os 
from deeplearning import object_detection
# webserver gateway interface
app = Flask(__name__)

BASE_PATH = os.getcwd()
UPLOAD_PATH = os.path.join(BASE_PATH,'static/upload/')


@app.route('/',methods=['POST','GET'])
def index():
    if request.method == 'POST':
        
            upload_file = request.files['image_name']
            filename = upload_file.filename
            path_save = os.path.join(UPLOAD_PATH,filename)
            upload_file.save(path_save)
            if request.form.get('countries') =="china":
                text_list = object_detection(path_save,"china")
            else:
                text_list = object_detection(path_save,"other")
            text_res = ""
            count = 1
            for ls in text_list:
                if ls["plate_color"] !="":
                    text_res += str(count)+". "+ls["plate_no"]+" "+"("+ls["plate_color"]+") "
                else:
                    text_res += str(count)+". "+ls["plate_no"]
                count+=1            
                
            return render_template('index.html',upload=True,upload_image=filename,text=text_res,no=len(text_list))

    return render_template('index.html',upload=False)


if __name__ =="__main__":
    
    app.run(debug=True)

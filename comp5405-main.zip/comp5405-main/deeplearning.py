import numpy as np
import cv2
import matplotlib.pyplot as plt
import os
import onnxruntime
import numpy as np
import copy
import os
from PIL import Image, ImageDraw, ImageFont
from alphabets import plate_chr

import easyocr

clors = [(255,0,0),(0,255,0),(0,0,255),(255,255,0),(0,255,255)]

"========================="

def object_detection(path,country):
    # Read image
    providers =  ['CPUExecutionProvider']
    
    # Load both pre-trained recognition and detection ONNX models 
    session_rec = onnxruntime.InferenceSession('./static/models/ch_plate_rec.onnx', providers=providers )
    session_detect = onnxruntime.InferenceSession('./static/models/ch_plate_detect.onnx', providers=providers )
    img=cv2.imread(path)
    
    # Create a copy for the original img
    img0 = copy.deepcopy(img)
    img,r,left,top = detect_pre_precessing(img,[640,640]) # Pre-processing before detection
    
    # Run the detection model to get a tensor represeneting a license plate
    y_onnx = session_detect.run([session_detect.get_outputs()[0].name], {session_detect.get_inputs()[0].name: img})[0]
    outputs = post_precessing(y_onnx,r,left,top) # Post-processing after detection, and prepare for recognition
    
    # Run the recognition model
    img_name = os.path.basename(path)
    result_list=rec_plate(outputs,img0,session_rec,country,img_name)
    ori_img = draw_result(img0,result_list)
    save_img_path = os.path.join("./static/predict/",img_name)
    cv2.imwrite(save_img_path,ori_img)
    return result_list
        
    

def cv_imread(path): #cv2 read chinese path 
    img=cv2.imdecode(np.fromfile(path,dtype=np.uint8),-1)
    return img

mean_value,std_value=((0.588,0.193)) # Mean and standard deviation of the training set
plate_color_list=['Black','Blue','Green','White','Yellow']
def decodePlate(preds):        # Decode the license plate
    pre=0
    newPreds=[]
    # Remove the repeated characters in the recognition result
    for i in range(len(preds)):
        if preds[i]!=0 and preds[i]!=pre:
            newPreds.append(preds[i])
        pre=preds[i]
    plate=""
    for i in newPreds:
        plate+=plate_chr[int(i)]
    return plate

def rec_pre_precessing(img,size=(48,168)): # Pre-processing before recognition
    img =cv2.resize(img,(168,48))
    img = img.astype(np.float32)
    img = (img/255-mean_value)/std_value  # Normalizes the pixel values by subtracting the mean value and dividing by the standard deviation value
    img = img.transpose(2,0,1)         # Convert channel,height,width to channel,height,channel
    img = img.reshape(1,*img.shape)    # Convert to 4D tensor with batch size of 1 at dimension 0
    return img

def get_en_plate_result(img): # Use EasyOCR to recognize the license plate
    reader = easyocr.Reader(['en','vi']) # Tell EasyOCR to recognize English
    result = reader.readtext(img) # Get the recognition result
    print(result[0][1])
    return result[0][1]


def get_plate_result(img,session_rec): # Get the recognition result of the license plate using pre-trained ONNX model for color and character recognition
    img =rec_pre_precessing(img) # Pre-processing before recognition
    y_onnx_plate,y_onnx_color = session_rec.run([session_rec.get_outputs()[0].name,session_rec.get_outputs()[1].name], {session_rec.get_inputs()[0].name: img}) # Run the recognition model to get the recognition result
    index =np.argmax(y_onnx_plate,axis=-1) # Get the index of the maximum value in the y_onnx_plate array
    index_color = np.argmax(y_onnx_color) # Get the index of the maximum value in the y_onnx_color array
    plate_color = plate_color_list[index_color]
    plate_no = decodePlate(index[0])
    return plate_no,plate_color


def get_split_merge(img):  # Split double-row license plate and merge into a single-row license plate
    h,w,c = img.shape
    img_upper = img[0:int(5/12*h),:] # Selects the top part of the image, by indexing the rows from the top of the image up to 5/12 of its height
    img_lower = img[int(1/3*h):,:] # Selects the bottom part of the image, by indexing the rows from 1/3 of its height to the bottom
    img_upper = cv2.resize(img_upper,(img_lower.shape[1],img_lower.shape[0])) # Resize the top part of the image to the same width as the bottom part
    new_img = np.hstack((img_upper,img_lower)) # Merge the two parts of the image
    return new_img

def order_points(pts):     # Rearranges them in a specific order to obtain the top-left, top-right, bottom-right, and bottom-left corners of the ROI
    rect = np.zeros((4, 2), dtype = "float32")
    s = pts.sum(axis = 1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    # 4 points, the top-left point will have the smallest x coordinate sum, whereas the bottom-right point will have the largest x coordinate sum
    diff = np.diff(pts, axis = 1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect


def four_point_transform(image, pts):  # Perspective transformation on an image given the four points that define a quadrilateral region of interest (ROI) for recognition
    rect = order_points(pts)
    (tl, tr, br, bl) = rect # top-left, top-right, bottom-right, and bottom-left
    
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2)) 
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    # compute the width of the new image, which will be the maximum distance between bottom-right and bottom-left x-coordinates or the top-right and top-left x-coordinates
    maxWidth = max(int(widthA), int(widthB))
    heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    # compute the height of the new image, which will be the maximum distance between the top-right and bottom-right y-coordinates or the top-left and bottom-left y-coordinates
    maxHeight = max(int(heightA), int(heightB))
    
    # construct the set of destination points to obtain a "birds eye view", (i.e. top-down view) of the image, again specifying points in the top-left, top-right, bottom-right, and bottom-left order
    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]], dtype = "float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    # apply the perspective transformation matrix
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight)) # obtain a top-down view of the original image
    
    return warped

def my_letter_box(img,size=(640,640)):  #
    h,w,c = img.shape
    r = min(size[0]/h,size[1]/w) # Ratio
    new_h,new_w = int(h*r),int(w*r) # Scale the image
    top = int((size[0]-new_h)/2) # Compute padding
    left = int((size[1]-new_w)/2)
    
    bottom = size[0]-new_h-top # Compute padding
    right = size[1]-new_w-left
    img_resize = cv2.resize(img,(new_w,new_h)) # Resize the image
    img = cv2.copyMakeBorder(img_resize,top,bottom,left,right,borderType=cv2.BORDER_CONSTANT,value=(114,114,114))
    return img,r,left,top


def xywh2xyxy(boxes):   # Convert [x, y, w, h] to [x1, y1, x2, y2]
    xywh =copy.deepcopy(boxes)
    xywh[:,0]=boxes[:,0]-boxes[:,2]/2
    xywh[:,1]=boxes[:,1]-boxes[:,3]/2
    xywh[:,2]=boxes[:,0]+boxes[:,2]/2
    xywh[:,3]=boxes[:,1]+boxes[:,3]/2
    return xywh
 
def my_nms(boxes,iou_thresh):         #nms
    index = np.argsort(boxes[:,4])[::-1]
    keep = []
    while index.size >0:
        i = index[0]
        keep.append(i)
        x1=np.maximum(boxes[i,0],boxes[index[1:],0])
        y1=np.maximum(boxes[i,1],boxes[index[1:],1])
        x2=np.minimum(boxes[i,2],boxes[index[1:],2])
        y2=np.minimum(boxes[i,3],boxes[index[1:],3])
        
        w = np.maximum(0,x2-x1)
        h = np.maximum(0,y2-y1)

        inter_area = w*h
        union_area = (boxes[i,2]-boxes[i,0])*(boxes[i,3]-boxes[i,1])+(boxes[index[1:],2]-boxes[index[1:],0])*(boxes[index[1:],3]-boxes[index[1:],1])
        iou = inter_area/(union_area-inter_area)
        idx = np.where(iou<=iou_thresh)[0]
        index = index[idx+1]
    return keep

def restore_box(boxes,r,left,top):  # Restores coordinates to the original image space 
    boxes[:,[0,2,5,7,9,11]]-=left
    boxes[:,[1,3,6,8,10,12]]-=top

    boxes[:,[0,2,5,7,9,11]]/=r
    boxes[:,[1,3,6,8,10,12]]/=r
    return boxes

def detect_pre_precessing(img,img_size):  # Pre-processing before detection
    
    # Resizes the image while maintaining its aspect ratio and placing it within a larger blank image of size img_size
    img,r,left,top=my_letter_box(img,img_size) # r is scaling ratio, left and top are the offsets of the image
    img =img[:,:,::-1].transpose(2,0,1).copy().astype(np.float32) # Convert BGR to RGB and HWC (height, width, channels) to CHW (channels, height, width), and convert to float32
    img=img/255 # Normalization to the image data, scales the pixel values to a range between 0 and 1, used to improve the performance of deep learning models by reducing the range of input values
    img=img.reshape(1,*img.shape) # Add a dimension to the array, the shape of the array becomes (1, channels, height, width)
    return img,r,left,top

def post_precessing(dets,r,left,top,conf_thresh=0.3,iou_thresh=0.5):# Post-processing after detection
    # Selects the bounding box with a confidence greater than conf_thresh
    choice = dets[:,:,4]>conf_thresh
    # scales the width and height of the bounding boxes by the confidence score of the detection
    dets=dets[choice]
    dets[:,13:15]*=dets[:,4:5]
    box = dets[:,:4]
    # Converts the bounding box from xywh to xyxy, (center_x, center_y, width, height) to (x1, y1, x2, y2)
    boxes = xywh2xyxy(box)
    
    # Selects the bounding box with the highest confidence score
    score= np.max(dets[:,13:15],axis=-1,keepdims=True)
    
    # Finds the index
    index = np.argmax(dets[:,13:15],axis=-1).reshape(-1,1)
    # Concatenates the boxes, score to get the output
    output = np.concatenate((boxes,score,dets[:,5:13],index),axis=1) 
    # Performs non-maximum suppression on the output, remove overlapping bounding boxes that have a high degree of intersection over union (IoU) with each other
    reserve_=my_nms(output,iou_thresh) 
    # Selects the bounding box after non-maximum suppression
    output=output[reserve_] 
    # Restores the coordinates of the bounding box to the original image space
    output = restore_box(output,r,left,top)
    return output

def rec_plate(outputs,img0,session_rec,country,img_name):  # Recognition of license plate
    # Dictionary for storing the results
    dict_list=[]
    # For each detected license plate in the input list outputs
    for output in outputs:
        result_dict={}
        # Gets the coordinates of license plate's rectangle
        rect=output[:4].tolist()
        # Gets the coordinates of the four corners of the license plate
        land_marks = output[5:13].reshape(4,2)
        roi_img = four_point_transform(img0,land_marks) # Crops the license plate from the original image
        label = int(output[-1])
        # Gets the confidence score of the bounding box
        score = output[4]
        if label==1:  # When the license plate is double-row
            roi_img = get_split_merge(roi_img)
        if country =="china":
            plate_no,plate_color = get_plate_result(roi_img,session_rec) # Recognition of license plate using pre-trained ONNX model for color and character
            result_dict['rect']=rect
            result_dict['landmarks']=land_marks.tolist()
            result_dict['plate_no']=plate_no
            result_dict['roi_height']=roi_img.shape[0]
            result_dict['plate_color']=plate_color
            dict_list.append(result_dict)
        else:
            plate_no = get_en_plate_result(roi_img); # Use easyocr to recognize the license plate
            result_dict['rect']=rect
            result_dict['landmarks']=land_marks.tolist()
            result_dict['plate_no']=plate_no
            result_dict['roi_height']=roi_img.shape[0]
            result_dict['plate_color']=""
            dict_list.append(result_dict)
    cv2.imwrite("./static/roi/{plate}".format(plate=img_name),roi_img) # Saves the cropped license plate image"
    return dict_list


def cv2ImgAddText(img, text, left, top, textColor, textSize=20):  # Adds text to the image
    if (isinstance(img, np.ndarray)):  
        img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)) 
    draw = ImageDraw.Draw(img)
    fontText = ImageFont.truetype(
        "fonts/platech.ttf", textSize, encoding="utf-8") # Loads the font
    draw.text((left, top), text, textColor, font=fontText)
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)

def draw_result(orgimg,dict_list):
    result_str =""
    for result in dict_list:
        rect_area = result['rect']
        
        x,y,w,h = rect_area[0],rect_area[1],rect_area[2]-rect_area[0],rect_area[3]-rect_area[1]
        padding_w = 0.05*w
        padding_h = 0.11*h
        rect_area[0]=max(0,int(x-padding_w))
        rect_area[1]=min(orgimg.shape[1],int(y-padding_h))
        rect_area[2]=max(0,int(rect_area[2]+padding_w))
        rect_area[3]=min(orgimg.shape[0],int(rect_area[3]+padding_h))

        height_area = result['roi_height']
        landmarks=result['landmarks']
        plate_no = result['plate_no']
        plate_color = result['plate_color']
        result_str+=plate_no+" "+plate_color
        for i in range(4):  # Draw the four corners of the license plate
            cv2.circle(orgimg, (int(landmarks[i][0]), int(landmarks[i][1])), 5, clors[i], -1)
        cv2.rectangle(orgimg,(rect_area[0],rect_area[1]),(rect_area[2],rect_area[3]),(255,255,0),2) # Draw the rectangle of the license plate
        print(result_str)
        labelSize = cv2.getTextSize(result_str,cv2.FONT_HERSHEY_SIMPLEX,0.5,1) # Get the size of the text
        if rect_area[0]+labelSize[0][0]>orgimg.shape[1]:                 # If the text exceeds the image, adjust the position of the text
            rect_area[0]=int(orgimg.shape[1]-labelSize[0][0])
        orgimg=cv2.rectangle(orgimg,(rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1]))),(int(rect_area[0]+round(1.2*labelSize[0][0])),rect_area[1]+labelSize[1]),(255,255,255),cv2.FILLED) # Draw the rectangle background of the text
        if len(result_str)>=1: # Draw the text according to the color of the license plate
            if plate_color=="Blue":
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),(0,0,255),21)

            elif plate_color == "Yellow":
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),(255,255,0),21)

            elif plate_color == "Green":
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),(0,255,0),21)

            elif plate_color == "White":
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),(255,255,255),21)

            elif plate_color == "Black":
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),21)

            else:
                orgimg=cv2ImgAddText(orgimg,result_str,rect_area[0],int(rect_area[1]-round(1.6*labelSize[0][1])),(0,255,0),21)

    print(result_str)
    return orgimg

    